<?php
$koneksi = new mysqli ("localhost","root","","si_pegawai");
?>

<!-- end -->